import pytest
from app.pipeline.orchestrator import run_pipeline
import asyncio

@pytest.mark.asyncio
async def test_run_pipeline():
    result = await run_pipeline("graphene batteries")
    assert "result" in result
