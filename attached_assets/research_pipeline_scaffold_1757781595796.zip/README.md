# Research Pipeline

Starter scaffold matching the ASCII flowchart.
