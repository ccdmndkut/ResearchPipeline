from fastapi import APIRouter
from app.pipeline.orchestrator import run_pipeline

router = APIRouter()

@router.get("/health")
async def health():
    return {"status": "ok"}

@router.post("/query")
async def query(payload: dict):
    return await run_pipeline(payload.get("query", ""))

@router.get("/index")
async def index():
    return {"message": "Index placeholder"}

def register_routes(app):
    app.include_router(router)
