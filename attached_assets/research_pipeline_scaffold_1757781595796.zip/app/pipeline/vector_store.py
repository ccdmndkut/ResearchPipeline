async def index_to_vectorDB(docs):
    return "indexed"

async def retrieve_docs(query):
    return [f"Retrieved doc for {query}"]
