async def build_graph(docs):
    # Mock: build simple graph representation
    return {"nodes": ["A","B"], "edges":[("A","B")]}
