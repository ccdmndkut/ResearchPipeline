async def compose_response(docs, graph, retrieved):
    return f"Composed answer with {len(docs)} docs, graph nodes {graph['nodes']}"
