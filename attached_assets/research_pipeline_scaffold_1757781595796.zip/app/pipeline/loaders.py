async def load_documents(query: str):
    # Mock: return dummy docs
    return [f"Document about {query}"]

async def validate_schema(docs):
    return True
