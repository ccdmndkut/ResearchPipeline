async def clean_text(text):
    return text.strip()

async def detect_language(text):
    return "en"

async def chunk_text(text):
    return [text]
