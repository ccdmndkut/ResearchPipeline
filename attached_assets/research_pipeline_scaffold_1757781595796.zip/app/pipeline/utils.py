def read_config():
    return {"mock": True}

def cache_result(key, value):
    pass

def slugify(text):
    return text.lower().replace(" ", "-")
