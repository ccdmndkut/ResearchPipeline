import asyncio
from app.pipeline.loaders import load_documents
from app.pipeline.graph_builder import build_graph
from app.pipeline.vector_store import index_to_vectorDB, retrieve_docs
from app.pipeline.composer import compose_response

async def plan_workflow(query: str):
    return f"Plan for query: {query}"

async def call_llm(prompt: str):
    await asyncio.sleep(0.1)
    return f"[MOCK LLM OUTPUT] {prompt}"

async def merge_results(parts):
    return "\n".join(parts)

async def run_pipeline(query: str):
    docs = await load_documents(query)
    graph = await build_graph(docs)
    await index_to_vectorDB(docs)
    retrieved = await retrieve_docs(query)
    composed = await compose_response(docs, graph, retrieved)
    return {"result": composed}
