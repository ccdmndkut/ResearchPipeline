async def web_search(query):
    return [f"Web result for {query}"]

async def summarize(text):
    return f"Summary of {text}"

async def cite_sources(sources):
    return f"Citations for {len(sources)} sources"
