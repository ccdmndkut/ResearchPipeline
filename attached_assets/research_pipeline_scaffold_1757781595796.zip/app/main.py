from fastapi import FastAPI
from app.routes import register_routes

def create_app():
    app = FastAPI()
    register_routes(app)
    return app

def run_dev():
    import uvicorn
    uvicorn.run("app.main:create_app", host="0.0.0.0", port=8000, reload=True)

if __name__ == "__main__":
    run_dev()
